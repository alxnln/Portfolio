Vous vous êtes fait enlevé par une vilaine sorcière.

L'objectif ici est de retrouver plusieurs codes cachés à l'aide de commandes bash.
Pour connaître les détails de l'histoire, exécutez le script "narration".

Vous arriverez-vous à vous échapper ?

