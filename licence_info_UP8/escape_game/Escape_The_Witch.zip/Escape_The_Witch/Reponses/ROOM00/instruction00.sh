#!/bin/bash

echo "Vous apercevez un simple bureau avec quelques papiers dessus."
echo "Approchez-vous pour les lire. (cd bureau)"
echo "Les papiers sont tous vides sauf un..."

read -p "Entrez le code: " CODE00
if [ "$CODE00" = "grenouille" ]; then
		echo "ROOM01 est désormais ouverte."
		cp -r ../Reponses/ROOM01 ../ROOM01
elif [ "$CODE00" = "indice" ]; then
		echo "Il manque la feuille04 non? ls n'est pas suffisant pour l'afficher."
else
		echo "Revenez exécuter les scripts chaques fois qu'un code est trouvé."
		echo "Tapez 'indice' à la place du code pour un indice."
fi