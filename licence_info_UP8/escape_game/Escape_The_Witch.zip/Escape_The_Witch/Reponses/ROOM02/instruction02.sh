#!/bin/bash

echo "C'est bien, ça alors, déjà dans la ROOM02!"
echo "Trop facile tu dis? Je vais bloquer l'accès à mon grimoire..."

read -p "Entrez le code: " CODE02
if [ "$CODE02" = "vinaigre" ]; then
		echo "ROOM03 est désormais ouverte."
		cp -r ../Reponses/ROOM03 ../ROOM03
elif [ "$CODE02" = "indice" ]; then
		echo "Il faut modifier les droits d'accès au grimoire."
else
		echo "Mauvais code."
fi
