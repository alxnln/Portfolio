#!/bin/bash

echo "Ouah, déjà dans la ROOM03!"
echo "Le code est caché à la ligne contenant trois caractères."
echo "Oui, pardon, j'ai que des feuilles chez moi..."

read -p "Entrez le code: " CODE03
if [ "$CODE03" = "sel" ]; then
		echo "ROOM04 est désormais ouverte."
		cp -r ../Reponses/ROOM04 ../ROOM04
elif [ "$CODE03" = "indice" ]; then
		echo "Les expressions régulières te disent quelque chose?"
else
		echo "Mauvais code."
fi
