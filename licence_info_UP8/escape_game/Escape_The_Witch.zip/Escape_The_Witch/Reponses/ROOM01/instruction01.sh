#!/bin/bash

echo "Vous voilà dans la ROOM01!"
echo "Une feuille est collée au mur."
echo "Une très longue feuille... avec beaucoup de texte..."
echo "Peu importe, le code se trouve sur la ligne contenant le mot 'CODE'."

read -p "Entrez le code: " CODE01

if [ "$CODE01" = "gingembre" ]; then
		echo "ROOM02 est désormais ouverte."
		cp -r ../Reponses/ROOM02 ../ROOM02
elif [ "$CODE01" = "indice" ]; then
		echo "la commande mystère commence par un g..."
else
		echo "Mauvais code."
fi