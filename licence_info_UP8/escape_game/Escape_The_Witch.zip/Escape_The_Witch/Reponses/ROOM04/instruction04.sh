#!/bin/bash

echo "Eheheh..."
echo "J'ai une comptine que j'adorais petite."
echo "Le code se trouve sur la feuille contenant 20 lignes, sur la 15e ligne."

read -p "Entrez le code: " CODE04
if [ "$CODE04" = "nougats" ]; then
		echo "Félicitations! vous avez réussi à vous échapper!"
		echo "Vous commencez déjà à me manquer..."
elif [ "$CODE04" = "indice" ]; then
		echo "Non, plus d'indices!"
                echo "Non, je plaisante."
                echo "Non, je plaisante pas."
else
		echo "Dernière ligne droite!"
fi