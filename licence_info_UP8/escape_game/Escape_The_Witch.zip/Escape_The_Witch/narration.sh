#!/bin/bash

read -p "Entrez votre nom: " PLAYER

echo "Bienvenue dans mon manoire $PLAYER!"
echo "Pourquoi êtes-vous ici?"
echo "Simplement parce que je voulais tester mon escape game!"
echo "Je vous met au défi de retrouver cinq codes pour vous échapper."
echo "Chaque code vous ouvrira une nouvelle ROOM."
echo "Pour débuter l'aventure, entrez dans la ROOM00 $PLAYER! Bon courage!"

cp -r Reponses/ROOM00 ROOM00

